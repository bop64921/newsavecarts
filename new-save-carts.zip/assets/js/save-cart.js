document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('.save-cart-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const cartName = form.querySelector('#cart_name').value;
     const data = new URLSearchParams();
data.append('action', 'save_cart_ajax');
data.append('cart_name', cartName);

fetch(save_cart_ajax_obj.ajax_url, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: data
})

        .then(res => res.text())
.then(text => {
    try {
        const response = JSON.parse(text);
        const container = form.closest('.woocommerce-form-coupon-toggle');
        container.querySelectorAll('.woocommerce-error, .woocommerce-message').forEach(el => el.remove());

        const msg = document.createElement('div');
        msg.className = response.success ? 'woocommerce-message' : 'woocommerce-error';
        msg.textContent = response.data?.message || 'Error desconocido';
        container.prepend(msg);
    } catch (e) {
        console.error('❌ No es JSON válido:', text);
    }
});
    });
});
